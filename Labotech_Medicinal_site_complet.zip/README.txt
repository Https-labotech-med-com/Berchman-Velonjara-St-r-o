LABOTECH MÉDICINAL — SITE WEB
===============================

Fichiers :
- index.html : page principale
- style.css  : design responsive
- script.js  : menu mobile et formulaire

IMPORTANT AVANT PUBLICATION :
1. Remplacer les coordonnées et informations génériques par les informations officielles.
2. Ajouter le logo et les photos réelles du laboratoire.
3. Vérifier les services, certifications et équipements réellement disponibles.
4. Connecter le formulaire à une adresse e-mail ou un service de formulaire.
5. Choisir un nom de domaine et un hébergement.

Le site est une base professionnelle prête à être personnalisée et publiée.
