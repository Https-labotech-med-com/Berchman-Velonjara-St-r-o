LABOTECH MÉDICINAL — VERSION FINALE
====================================

Cette version utilise les informations professionnelles visibles dans le CV fourni :
- Master en Chimie
- Licence en Chimie générale
- stages au Laboratoire Plante Santé (LPS) et BIONNEXX à Fianarantsoa
- compétences informatiques et techniques indiquées dans le CV
- langues et qualités professionnelles indiquées dans le CV
- téléphone et e-mail indiqués dans le CV

PROTECTION DES DONNÉES :
Le site public n'affiche volontairement PAS la date de naissance, la situation familiale,
le numéro de CNI ni l'adresse exacte présents sur le CV. Ces données ne devraient pas
être publiées sur un site web public.

AVANT PUBLICATION :
1. Vérifier le nom exact à afficher et l'orthographe.
2. Ajouter les vraies photos du laboratoire, si disponibles.
3. Ajouter uniquement les prestations, équipements et certifications réellement disponibles.
4. Connecter le formulaire de contact à un service e-mail.
5. Choisir un hébergement et un nom de domaine.
