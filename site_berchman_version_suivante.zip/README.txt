SITE BERCHMAN — VERSION SUIVANTE

Contenu:
- index.html : page complète
- style.css : design responsive
- script.js : menu mobile et année automatique

Le site est prêt à être publié sur un hébergeur statique. Cette archive ne publie pas automatiquement le site sur Internet et ne demande aucune carte bancaire.

Coordonnées intégrées:
Téléphone: 038 68 527 67
Email: berchmanvelonjarastereo@gmail.com
Localisation: Fianarantsoa, Madagascar

Le contenu volontairement sensible du CV (CNI, date de naissance, situation familiale, adresse exacte) n'est pas affiché.
