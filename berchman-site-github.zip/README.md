# Site professionnel — Berchman Velonjara Stéréo

Site vitrine statique en HTML/CSS, prêt pour une publication avec GitHub Pages.

## Publication
1. Créer un dépôt GitHub public.
2. Ajouter `index.html` à la racine du dépôt.
3. Dans Settings → Pages, choisir la branche `main` et le dossier `/root`.
4. Enregistrer puis attendre la publication.

## À personnaliser
- Ajouter la photo professionnelle.
- Ajouter les informations détaillées du CV.
- Ajouter les liens professionnels.
- Ajouter, après vérification, les services et moyens de paiement réellement disponibles.
